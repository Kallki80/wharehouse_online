import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'payment_page.dart';

import 'api_config.dart';

enum LmdTabType { entryForm, manageClients, manageDrivers, manageVehicles }

class LmdPage extends StatefulWidget {
  final Map<String, dynamic>? dataToEdit;

  const LmdPage({super.key, this.dataToEdit});

  @override
  State<LmdPage> createState() => _LmdPageState();
}

class _LocationEntry {
  String? selectedClient;
  bool isOtherClient = false;

  /// When autofill sets SO number successfully, we lock the dropdown so
  /// user clicking does not show the full list.
  bool isSoLocked = false;

  final clientNameController = TextEditingController();
  final soNumberController = TextEditingController();

  void dispose() {
    clientNameController.dispose();
    soNumberController.dispose();
  }

  void clear() {
    selectedClient = null;
    isOtherClient = false;
    isSoLocked = false;
    clientNameController.clear();
    soNumberController.clear();
  }
}


class _LmdPageState extends State<LmdPage> {
  LmdTabType _currentTab = LmdTabType.entryForm;
  
  final _formKey = GlobalKey<FormState>();
  Future<List<Map<String, dynamic>>>? _lmdDataFuture;

  final _vehicleNumberController = TextEditingController();
  final _driverNameController = TextEditingController();
  final _newDriverCtrl = TextEditingController();
  final _newVehicleCtrl = TextEditingController();
  final _gateNumberController = TextEditingController();
  bool _isOtherDriver = false;
  bool _isOtherVehicle = false;
  final _dateController = TextEditingController();
  final _clientLocationController = TextEditingController();
  final _timeController = TextEditingController();

  DateTime? ctrlDate;

  final List<_LocationEntry> _locations = [];
  List<String> _clientList = [];
  List<String> _availableSOs = [];
  List<Map<String, dynamic>> _allSOData = [];
  List<String> _driverList = [];
  List<String> _vehicleList = [];
  bool _isLoading = true;

  Map<String, dynamic>? _paymentDetails;
  bool get _isEditMode => widget.dataToEdit != null;

  @override
  void initState() {
    super.initState();
    _locations.add(_LocationEntry());

    _loadInitialData().then((_) {
      if (_isEditMode) {
        _populateFields(widget.dataToEdit!);
      } else {
        _dateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
        _timeController.text = DateFormat('HH:mm:ss').format(DateTime.now());
      }
      _refreshData();
    });
  }

  Future<void> _loadInitialData() async {
    setState(() => _isLoading = true);
    try {
      final List<Future<http.Response>> futures = [
        http.get(Uri.parse('$apiBaseUrl/get_vendors')),
        http.get(Uri.parse('$apiBaseUrl/get_all_generated_sos_with_items')),
        http.get(Uri.parse('$apiBaseUrl/get_drivers')),
        http.get(Uri.parse('$apiBaseUrl/get_vehicles')),
      ];
      
      final responses = await Future.wait(futures);
      
      if (responses.every((r) => r.statusCode == 200)) {
        final List<dynamic> clientsJson = json.decode(responses[0].body);
        final List<dynamic> sosJson = json.decode(responses[1].body);
        final List<dynamic> driversJson = json.decode(responses[2].body);
        final List<dynamic> vehiclesJson = json.decode(responses[3].body);
        
        final clients = clientsJson.map((e) => e.toString()).toList();
        final sos = List<Map<String, dynamic>>.from(sosJson);
        final drivers = driversJson.map((e) => e.toString()).where((d) => d.isNotEmpty).toList();
        debugPrint('LMD Raw drivers from API: $driversJson');
        debugPrint('LMD Loaded drivers: ${drivers.isEmpty ? ["Other"] : ["Other", ...drivers]}');
        final vehicles = vehiclesJson.map((e) => e.toString()).where((v) => v.isNotEmpty).toList();
        debugPrint('LMD Raw vehicles from API: $vehiclesJson');
        debugPrint('LMD Loaded vehicles: ${vehicles.isEmpty ? ["Other"] : ["Other", ...vehicles]}');
        
        setState(() {
          _clientList = {"Other", ...clients.where((c) => c != "Other")}.toList();
          _driverList = drivers.isEmpty ? ["Other"] : ["Other", ...drivers];
          _vehicleList = vehicles.isEmpty ? ["Other"] : ["Other", ...vehicles];
          _allSOData = sos;
          _availableSOs = sos.map((e) => e['so_number']?.toString() ?? "").where((s) => s.isNotEmpty).toSet().toList();
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint('LMD _loadInitialData error: $e');
      setState(() => _isLoading = false);
    }
  }

  // void _autoFillSO(int index) {
  //   final location = _locations[index];
  //   final client = location.selectedClient;
  //   final date = _dateController.text;

  //   if (client != null && client != "Other" && date.isNotEmpty) {
  //     try {
  //       final match = _allSOData.firstWhere((so) {
  //         final soClient = (so['client_name'] ?? so['vendor_name'] ?? '').toString();
  //         final soDate = (so['date'] ?? '').toString();
  //         return soClient.toLowerCase() == client.toLowerCase() && soDate.contains(date);
  //       });
  //       setState(() {
  //         location.soNumberController.text = match['so_number'] ?? '';
  //       });
  //     } catch (e) {
  //       // No match found
  //     }
  //   }
  // }


  // void _autoFillSO(int index) {
  //   final location = _locations[index];
  //   final client = location.selectedClient?.trim();
  //   // final selectedDate = _dateController.text.trim();

  //   final selectedDate =
  //   ctrlDate != null
  //       ? DateFormat('yyyy-MM-dd').format(ctrlDate!)
  //       : '';

  //   if (client == null || client.isEmpty || selectedDate.isEmpty) {
  //     return;
  //   }

  //   try {



  //     debugPrint("================================");
  //     debugPrint("Selected Client: $client");
  //     debugPrint("Selected Date: $selectedDate");
  //     debugPrint("SO Count: ${_allSOData.length}");

  //     for (var so in _allSOData.take(5)) {
  //       debugPrint(
  //         "SO=${so['so_number']} | "
  //         "Client=${so['client_name']} | "
  //         "Dispatch=${so['date_of_dispatch']}"
  //       );
  //     }
  //     final match = _allSOData.firstWhere((so) {

  //       final soClient =
  //           (so['client_name'] ?? '').toString().trim();

  //       // final dispatchDate =
  //       //     (so['date_of_dispatch'] ?? '').toString().trim();

  //       final dispatchDate =
  //           (so['date_of_dispatch'] ?? '')
  //               .toString()
  //               .split(' ')
  //               .first
  //               .trim();


        
  //       return soClient.toLowerCase() == client.toLowerCase()
  //           && dispatchDate == selectedDate;
  //     });

  //     setState(() {
  //       location.soNumberController.text =
  //           match['so_number']?.toString() ?? '';
  //     });

  //   } catch (e) {
  //     setState(() {
  //       location.soNumberController.clear();
  //     });
  //   }
  // }

  // void _autoFillSO(int index) {
  //   final location = _locations[index];
  //   final client = location.selectedClient?.trim();

  //   final selectedDate =
  //       ctrlDate != null
  //           ? DateFormat('yyyy-MM-dd').format(ctrlDate!)
  //           : '';

  //   if (client == null || client.isEmpty || selectedDate.isEmpty) {
  //     return;
  //   }

  //   try {

  //     debugPrint("================================");
  //     debugPrint("Selected Client: $client");
  //     debugPrint("Selected Date: $selectedDate");
  //     debugPrint("SO Count: ${_allSOData.length}");

  //     final matches = _allSOData.where((so) {
  //       final dispatchDate = (so['date_of_dispatch'] ?? '')
  //           .toString()
  //           .split(' ')
  //           .first
  //           .trim();

  //       return dispatchDate == selectedDate;
  //     }).toList();

  //     debugPrint("Date Matches Found: ${matches.length}");

  //     for (var m in matches.take(20)) {
  //       debugPrint(
  //         "Client=${m['client_name']} | "
  //         "SO=${m['so_number']} | "
  //         "Date=${m['date_of_dispatch']}"
  //       );
  //     }

  //     final match = _allSOData.firstWhere((so) {
  //       final soClient =
  //           (so['client_name'] ?? '').toString().trim();

  //       final dispatchDate =
  //           (so['date_of_dispatch'] ?? '')
  //               .toString()
  //               .split(' ')
  //               .first
  //               .trim();

  //       return soClient.toLowerCase() == client.toLowerCase() &&
  //           dispatchDate == selectedDate;
  //     });

  //     debugPrint(
  //       "MATCH FOUND => SO=${match['so_number']} | "
  //       "Client=${match['client_name']}"
  //     );

  //     setState(() {
  //       location.soNumberController.text =
  //           match['so_number']?.toString() ?? '';
  //     });

  //   } catch (e) {

  //     debugPrint("NO MATCH FOUND");
  //     debugPrint("ERROR: $e");

  //     setState(() {
  //       location.soNumberController.clear();
  //     });
  //   }
  // }



  void _autoFillSO(int index) async {
    final location = _locations[index];
    final client = location.selectedClient?.trim();

    final selectedDate = ctrlDate != null
        ? DateFormat('yyyy-MM-dd').format(ctrlDate!)
        : '';

    if (client == null || client.isEmpty || selectedDate.isEmpty) {
      return;
    }

    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/get_so_by_client_and_date'
          '?client_name=${Uri.encodeComponent(client)}'
          '&ctrl_date=$selectedDate'
        ),
      );

      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        setState(() {
          location.soNumberController.text =
              data['so_number'].toString();
          location.isSoLocked = true;
        });
      } else {
        setState(() {
          location.soNumberController.clear();
          location.isSoLocked = false;
        });
      }


    } catch (e) {
      setState(() {
        location.soNumberController.clear();
      });
    }
  }












  void _populateFields(Map<String, dynamic> data) {
    _gateNumberController.text = (data['gate_number'] ?? '').toString();
    String clientName = data['client_name'] ?? '';
    if (_clientList.contains(clientName)) {
      _locations.first.selectedClient = clientName;
    } else {
      _locations.first.selectedClient = "Other";
      _locations.first.isOtherClient = true;
      _locations.first.clientNameController.text = clientName;
    }

    _locations.first.soNumberController.text = data['po_number'] ?? '';

    String vehicleNum = data['vehicle_number'] ?? '';
    if (_vehicleList.contains(vehicleNum) && vehicleNum.isNotEmpty) {
      _vehicleNumberController.text = vehicleNum;
    } else {
      _isOtherVehicle = true;
      _newVehicleCtrl.text = vehicleNum;
    }

    String driverName = data['driver_name'] ?? '';
    if (_driverList.contains(driverName) && driverName.isNotEmpty) {
      _driverNameController.text = driverName;
    } else {
      _isOtherDriver = true;
      _newDriverCtrl.text = driverName;
    }

    _dateController.text = data['date'] ?? '';
    _timeController.text = data['time'] ?? '';
    _paymentDetails = data;
  }

  void _refreshData() {
    setState(() {
      _lmdDataFuture = http.get(Uri.parse('$apiBaseUrl/get_latest_lmd_data')).then((response) {
        if (response.statusCode == 200) {
          return List<Map<String, dynamic>>.from(json.decode(response.body));
        } else {
          throw Exception('Failed to load LMD data');
        }
      });
    });
  }

  @override
  void dispose() {
    _vehicleNumberController.dispose();
    _driverNameController.dispose();
    _newDriverCtrl.dispose();
    _newVehicleCtrl.dispose();
    _dateController.dispose();
    _timeController.dispose();
    _clientLocationController.dispose();
    for (var location in _locations) {
      location.dispose();
    }
    super.dispose();
  }

  void _submitForm() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (ctrlDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Please select CTRL date."),
        backgroundColor: Colors.redAccent,
      ));
      return;
    }

    List<String> finalClientNames = [];
    for (var loc in _locations) {
      String name = loc.isOtherClient ? loc.clientNameController.text.trim() : loc.selectedClient ?? '';
      if (loc.isOtherClient && name.isNotEmpty) {
        await http.post(Uri.parse('$apiBaseUrl/insert_vendor'), body: json.encode({'name': name}), headers: {'Content-Type': 'application/json'});
      }
      finalClientNames.add(name);
    }

    final clientNamesStr = finalClientNames.where((s) => s.isNotEmpty).join(', ');
    final soNumbers = _locations.map((e) => e.soNumberController.text.trim()).where((s) => s.isNotEmpty).join(', ');

    String finalVehicle = _isOtherVehicle ? _newVehicleCtrl.text.trim() : _vehicleNumberController.text;
    String finalDriver = _isOtherDriver ? _newDriverCtrl.text.trim() : _driverNameController.text;

    if (_isOtherVehicle && finalVehicle.isNotEmpty) {
      await http.post(Uri.parse('$apiBaseUrl/insert_vehicle'), body: json.encode({'number': finalVehicle}), headers: {'Content-Type': 'application/json'});
    }
    if (_isOtherDriver && finalDriver.isNotEmpty) {
      await http.post(Uri.parse('$apiBaseUrl/insert_driver'), body: json.encode({'name': finalDriver}), headers: {'Content-Type': 'application/json'});
    }

    final data = {
      'vehicle_number': finalVehicle,
      'driver_name': finalDriver,
      'date': _dateController.text,
      'time': _timeController.text,
      'client_name': clientNamesStr,
      'po_number': soNumbers,
      'client_location': '', 
      'vehicle_type': _paymentDetails?['vehicle_type'],
      'booking_person': _paymentDetails?['booking_person'],
      'km': _paymentDetails?['km'],
      'price_per_km': _paymentDetails?['price_per_km'],
      'extra_expenses': _paymentDetails?['extra_expenses'],
      'reason': _paymentDetails?['reason'],
      'total_amount': _paymentDetails?['total_amount'],
      'payment_status': _paymentDetails?['payment_status'],
      'mode_of_payment': _paymentDetails?['mode_of_payment'],
      'amount_paid': _paymentDetails?['amount_paid'],
      'amount_due': _paymentDetails?['amount_due'],
      'ctrl_date': ctrlDate != null ? DateFormat('yyyy-MM-dd').format(ctrlDate!) : null,
      'gate_number': _gateNumberController.text.trim(),
    };

    if (_isEditMode) {
      data['id'] = widget.dataToEdit!['id'];
      final response = await http.put(Uri.parse('$apiBaseUrl/update_lmd_data'), body: json.encode(data), headers: {'Content-Type': 'application/json'});
      if (response.statusCode == 200 && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('LMD Data Updated Successfully!'), backgroundColor: Colors.blue));
        Navigator.of(context).pop();
      }
    } else {
      final response = await http.post(Uri.parse('$apiBaseUrl/insert_lmd_data'), body: json.encode(data), headers: {'Content-Type': 'application/json'});
      if (response.statusCode == 200 && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('LMD Data Saved Successfully!'), backgroundColor: Colors.green));
        _resetForm();
        _loadInitialData();
        _refreshData();
      }
    }
  }

  Future<void> _refreshLists() async {
    await _loadInitialData();
    _refreshData();
  }

  void _resetForm() {
    _formKey.currentState!.reset();
    _gateNumberController.clear();
    _vehicleNumberController.clear();
    _driverNameController.clear();
    _newDriverCtrl.clear();
    _newVehicleCtrl.clear();
    _isOtherDriver = false;
    _isOtherVehicle = false;
    for (var location in _locations) {
      location.clear();
    }
    setState(() {
      _locations.removeRange(1, _locations.length);
      _locations.first.clear();
      _dateController.text = DateFormat('yyyy-MM-dd').format(DateTime.now());
      _timeController.text = DateFormat('HH:mm:ss').format(DateTime.now());
      _paymentDetails = null;
      ctrlDate = null;
    });
  }

  void _addLocation() {
    setState(() {
      _locations.add(_LocationEntry());
    });
  }

  void _removeLocation(int index) {
    if (_locations.length > 1) {
      setState(() {
        _locations[index].dispose();
        _locations.removeAt(index);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return DefaultTabController(
      length: LmdTabType.values.length,
      child: Scaffold(
        appBar: AppBar(
          title: Text(_isEditMode ? 'Edit LMD Entry' : 'LMD - Book Logistics (SO Link)', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          backgroundColor: theme.colorScheme.primary,
          foregroundColor: theme.colorScheme.onPrimary,
          bottom: TabBar(
            isScrollable: true,
            tabs: LmdTabType.values.map((tab) => Tab(
              text: tab == LmdTabType.entryForm 
                ? '📝 Entry Form' 
                : tab == LmdTabType.manageClients 
                  ? '👥 Clients (${_clientList.length})' 
                  : tab == LmdTabType.manageDrivers 
                    ? '🚛 Drivers (${_driverList.length})' 
                    : '🚗 Vehicles (${_vehicleList.length})',
            )).toList(),
            onTap: (index) {
              setState(() {
                _currentTab = LmdTabType.values[index];
              });
              if (!_isLoading) _refreshLists(); // Refresh on tab switch
            },
          ),
        ),
        body: _isLoading 
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              children: LmdTabType.values.map((tab) {
                switch (tab) {
                  case LmdTabType.entryForm:
                    return ListView(
                      padding: const EdgeInsets.all(16.0),
                      children: [
                        Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: _buildForm(theme),
                          ),
                        ),
                        if (!_isEditMode) ...[
                          const SizedBox(height: 24),
                          Text('Recent Entries', style: theme.textTheme.headlineSmall?.copyWith(color: theme.colorScheme.primary, fontSize: 18)),
                          const SizedBox(height: 10),
                          _buildDataTable(theme),
                        ],
                      ],
                    );
                  case LmdTabType.manageClients:
                    return _buildManagementList(theme, _clientList, 'Clients', (name, action, type) => _manageEntity(name, action, type), 'client');
                  case LmdTabType.manageDrivers:
                    return _buildManagementList(theme, _driverList, 'Drivers', (name, action, type) => _manageEntity(name, action, type), 'driver');
                  case LmdTabType.manageVehicles:
                    return _buildManagementList(theme, _vehicleList, 'Vehicles', (name, action, type) => _manageEntity(name, action, type), 'vehicle');
                }
              }).toList(),
            ),
      ),
    );
  }

  Widget _buildVehicleDropdown() {
    String? currentValue = _vehicleNumberController.text.isEmpty ? null : _vehicleNumberController.text;
    return DropdownButtonFormField<String>(
      initialValue: currentValue != null && _vehicleList.contains(currentValue) ? currentValue : null,
      decoration: InputDecoration(
        labelText: 'Vehicle Number * (${_vehicleList.length > 1 ? _vehicleList.length - 1 : 0} saved)',
        labelStyle: const TextStyle(fontSize: 13),
        border: const OutlineInputBorder(),
        prefixIcon: Icon(Icons.local_shipping, color: Theme.of(context).colorScheme.primary, size: 20),
      ),
      style: const TextStyle(fontSize: 13, color: Colors.black),
      items: _vehicleList.map((item) => DropdownMenuItem(
        value: item,
        child: Text(item, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
      )).toList(),
      onChanged: (String? newValue) {
        setState(() {
          _vehicleNumberController.text = newValue ?? '';
          _isOtherVehicle = newValue == 'Other';
          if (newValue != 'Other') {
            _newVehicleCtrl.clear();
          }
        });
      },
      validator: (value) => value == null || value.isEmpty ? 'Vehicle required' : null,
    );
  }

  Widget _buildDriverDropdown() {
    String? currentValue = _driverNameController.text.isEmpty ? null : _driverNameController.text;
    return DropdownButtonFormField<String>(
      initialValue: currentValue != null && _driverList.contains(currentValue) ? currentValue : null,
      decoration: InputDecoration(
        labelText: 'Driver Name * (${_driverList.length > 1 ? _driverList.length - 1 : 0} saved)',
        labelStyle: const TextStyle(fontSize: 13),
        border: const OutlineInputBorder(),
        prefixIcon: Icon(Icons.person_pin_rounded, color: Theme.of(context).colorScheme.primary, size: 20),
      ),
      style: const TextStyle(fontSize: 13, color: Colors.black),
      items: _driverList.map((item) => DropdownMenuItem(
        value: item,
        child: Text(item, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
      )).toList(),
      onChanged: (String? newValue) {
        setState(() {
          _driverNameController.text = newValue ?? '';
          _isOtherDriver = newValue == 'Other';
          if (newValue != 'Other') {
            _newDriverCtrl.clear();
          }
        });
      },
      validator: (value) => value == null || value.isEmpty ? 'Driver required' : null,
    );
  }

  Widget _buildForm(ThemeData theme) {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          _buildTextFormField(
            _gateNumberController,
            'Gate Number',
            Icons.door_front_door,
            theme,
          ),
          const SizedBox(height: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildVehicleDropdown(),
              if (_isOtherVehicle)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: _buildTextFormField(
                    _newVehicleCtrl,
                    'New Vehicle Number *',
                    Icons.add,
                    theme,
                    isRequired: true,
                    validator: (value) => value == null || value.isEmpty ? 'New vehicle number required' : null,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDriverDropdown(),
              if (_isOtherDriver)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: _buildTextFormField(
                    _newDriverCtrl,
                    'New Driver Name *',
                    Icons.person_add,
                    theme,
                    isRequired: true,
                    validator: (value) => value == null || value.isEmpty ? 'New driver name required' : null,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildTextFormField(
                  _dateController,
                  'Date',
                  Icons.calendar_today,
                  theme,
                  isRequired: true,
                  readOnly: true,
                  onTap: () async {
                    DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null) {
                      setState(() {
                        _dateController.text = DateFormat('yyyy-MM-dd').format(picked);
                      });
                      for (int i = 0; i < _locations.length; i++) {
                        _autoFillSO(i);
                      }
                    }
                  }
                ),
              ),
              const SizedBox(width: 16),
              Expanded(child: _buildTextFormField(_timeController, 'Time', Icons.access_time, theme, isRequired: true, readOnly: true)),
            ],
          ),
          const SizedBox(height: 16),
          _buildCtrlDateButton(theme),
          const SizedBox(height: 24),
          ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: _locations.length,
            itemBuilder: (context, index) => _buildLocationEntry(index, theme),
          ),
          const SizedBox(height: 16),
          if (!_isEditMode)
            TextButton.icon(icon: const Icon(Icons.add_location_alt_outlined, size: 20), label: const Text('Add Another Client', style: TextStyle(fontSize: 13)), onPressed: _addLocation),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.payment, size: 20),
            label: const Text('Proceed to Payment', style: TextStyle(fontSize: 15)),
            onPressed: () async {
              final result = await Navigator.push(context, MaterialPageRoute(builder: (context) => PaymentPage(initialData: _paymentDetails)));
              if (result != null) setState(() => _paymentDetails = result);
            },
            style: ElevatedButton.styleFrom(backgroundColor: theme.colorScheme.secondary, foregroundColor: theme.colorScheme.onSecondary, minimumSize: const Size(double.infinity, 50)),
          ),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: _submitForm, style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)), child: Text(_isEditMode ? 'Update' : 'Submit', style: const TextStyle(fontSize: 15))),
        ],
      ),
    );
  }

  Widget _buildLocationEntry(int index, ThemeData theme) {
    final location = _locations[index];
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(side: BorderSide(color: theme.dividerColor), borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Client ${index + 1}', style: theme.textTheme.titleMedium?.copyWith(fontSize: 14)),
                if (index > 0 && !_isEditMode) IconButton(icon: const Icon(Icons.remove_circle_outline, color: Colors.red, size: 20), onPressed: () => _removeLocation(index)),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: location.selectedClient,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Select Client', labelStyle: TextStyle(fontSize: 13), border: OutlineInputBorder(), prefixIcon: Icon(Icons.person, size: 20)),
              style: const TextStyle(fontSize: 13, color: Colors.black),
              items: _clientList.map((c) => DropdownMenuItem(value: c, child: Text(c, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)))).toList(),
              // onChanged: (val) => setState(() { 
              //   location.selectedClient = val; 
              //   location.isOtherClient = val == "Other"; 
              //   _autoFillSO(index);
              // }),
              onChanged: (value) {
                setState(() {
                  location.selectedClient = value;
                  location.isSoLocked = false;
                });

                _autoFillSO(index);
              },
              validator: (val) => val == null ? 'Required' : null,
            ),
          if (location.isOtherClient)
              Padding(padding: const EdgeInsets.only(top: 16.0), child: _buildTextFormField(location.clientNameController, 'New Client Name', Icons.edit_note, theme, isRequired: true, validator: (value) => value == null || value.isEmpty ? 'New client name required' : null,)),
            const SizedBox(height: 16),
            // DropdownButtonFormField<String>(
            //   initialValue: _availableSOs.contains(location.soNumberController.text) ? location.soNumberController.text : "",
            //   isExpanded: true,
            //   decoration: const InputDecoration(labelText: 'Linked SO Number', labelStyle: TextStyle(fontSize: 13), border: OutlineInputBorder(), prefixIcon: Icon(Icons.receipt_long, size: 20)),
            //   style: const TextStyle(fontSize: 13, color: Colors.black),
            //   items: location.isSoLocked
            //       ? [
            //           DropdownMenuItem(
            //             value: location.soNumberController.text,
            //             child: Text(location.soNumberController.text, style: const TextStyle(fontSize: 13)),
            //           )
            //         ]
            //       : [
            //           const DropdownMenuItem(value: "", child: Text("None", style: TextStyle(fontSize: 13))),
            //           ..._availableSOs.map((p) => DropdownMenuItem(value: p, child: Text(p, style: const TextStyle(fontSize: 13))))
            //         ],
            //   onChanged: (val) {
            //   if (location.isSoLocked) return;
            //     setState(() => location.soNumberController.text = val ?? "");
            //   },
            // ),

            DropdownButtonFormField<String>(
              initialValue: location.soNumberController.text.isNotEmpty
                  ? location.soNumberController.text
                  : "",

              isExpanded: true,

              decoration: const InputDecoration(
                labelText: 'Linked SO Number',
                labelStyle: TextStyle(fontSize: 13),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.receipt_long, size: 20),
              ),

              style: const TextStyle(fontSize: 13, color: Colors.black),

              items: location.soNumberController.text.isNotEmpty
                  ? [
                      DropdownMenuItem(
                        value: location.soNumberController.text,
                        child: Text(location.soNumberController.text,
                            style: const TextStyle(fontSize: 13)),
                      )
                    ]
                  : [
                      const DropdownMenuItem(
                        value: "",
                        child: Text("None", style: TextStyle(fontSize: 13)),
                      )
                    ],

              onChanged: (val) {
                setState(() {
                  location.soNumberController.text = val ?? "";
                });
              },
            )




          ],
        ),
      ),
    );
  }

  Widget _buildCtrlDateButton(ThemeData theme) {
    return OutlinedButton.icon(
      icon: const Icon(Icons.calendar_month_outlined, color: Colors.teal, size: 20),
      onPressed: () async {
        DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: ctrlDate ?? DateTime.now(),
          firstDate: DateTime(2000),
          lastDate: DateTime(2100),
        );
        // if (pickedDate != null) {
        //   setState(() => ctrlDate = pickedDate);
        // }
        if (pickedDate != null) {
          setState(() => ctrlDate = pickedDate);

          for (int i = 0; i < _locations.length; i++) {
            _autoFillSO(i);
          }
        }
      },
      label: Text(
        ctrlDate == null ? 'Select CTRL Date' : 'CTRL: ${DateFormat('dd-MM-yy').format(ctrlDate!)}',
        style: TextStyle(color: ctrlDate == null ? Colors.black54 : Colors.teal.shade700, fontSize: 13),
      ),
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        side: BorderSide(color: ctrlDate == null ? Colors.grey.shade400 : Colors.teal),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildTextFormField(
    TextEditingController controller, 
    String label, 
    IconData icon, 
    ThemeData theme, {
    bool isRequired = false, 
    bool readOnly = false, 
    VoidCallback? onTap,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      style: const TextStyle(fontSize: 13),
      decoration: InputDecoration(
        labelText: label, 
        labelStyle: const TextStyle(fontSize: 13), 
        border: const OutlineInputBorder(), 
        prefixIcon: Icon(icon, color: theme.colorScheme.primary, size: 20)
      ),
      validator: validator ?? (value) => (isRequired && (value == null || value.isEmpty)) ? 'Required' : null,
      readOnly: readOnly,
      onTap: onTap,
    );
  }

  Widget _buildManagementList(
    ThemeData theme, 
    List<String> items, 
    String title, 
    Future<void> Function(String, String, String) onAction, 
    String type
  ) {
    if (items.isEmpty || items.length == 1 && items.first == 'Other') {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_outlined, size: 64, color: theme.colorScheme.outline),
            const SizedBox(height: 16),
            Text('$title - No items', style: theme.textTheme.titleLarge),
            Text('Tap + to add your first $type', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.outline)),
          ],
        ),
      );
    }

    final filteredItems = items.where((i) => i != 'Other').toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text('$title (${filteredItems.length})', style: theme.textTheme.titleLarge),
        ),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('Name')),
                DataColumn(label: Text('Actions')),
              ],
              rows: filteredItems.map((name) => DataRow(cells: [
                DataCell(Text(name)),
                DataCell(Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: theme.colorScheme.primary),
                      onPressed: () => onAction(name, 'edit', type),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () => onAction(name, 'delete', type),
                    ),
                  ],
                )),
              ])).toList(),
            ),
          ),
        ),
        FloatingActionButton.extended(
          onPressed: () => onAction('', 'add', type),
          icon: Icon(Icons.add),
          label: Text('Add $type'),
          backgroundColor: theme.colorScheme.primary,
          foregroundColor: theme.colorScheme.onPrimary,
        ),
      ],
    );
  }








// ------------------ HELPERS ------------------

  String _getInsertUrl(String type) {
    return type == 'client'
        ? '$apiBaseUrl/insert_vendor'
        : type == 'driver'
            ? '$apiBaseUrl/insert_driver'
            : '$apiBaseUrl/insert_vehicle';
  }

  String capitalize(String s) =>
      s.isNotEmpty ? s[0].toUpperCase() + s.substring(1) : s;

  // ------------------ MANAGE ENTITY ------------------

  Future<void> _manageEntity(String name, String action, String type) async {
    TextEditingController nameCtrl = TextEditingController(text: name);
    TextEditingController pwdCtrl = TextEditingController();

    final isDelete = action == 'delete';

    bool confirmed = await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(
              isDelete
                  ? 'Delete $name ($type)?'
                  : action == 'add'
                      ? 'Add New $type'
                      : 'Edit $name ($type)',
            ),
            content: isDelete
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Enter LMD password:'),
                      const SizedBox(height: 10),
                      TextField(
                        controller: pwdCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Password (1008)',
                          border: OutlineInputBorder(),
                        ),
                        obscureText: true,
                        autofocus: true,
                      ),
                    ],
                  )
                : TextField(
                    controller: nameCtrl,
                    decoration: InputDecoration(
                      labelText: '${capitalize(type)} Name',
                      border: const OutlineInputBorder(),
                    ),
                    autofocus: true,
                  ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                child: Text(isDelete ? 'DELETE' : action.toUpperCase()),
              ),
            ],
          ),
        ) ??
        false;

    if (!confirmed) return;

    final pwd = isDelete ? pwdCtrl.text : null;
    final updatedName = nameCtrl.text;

    await _performEntityAction(updatedName, action, pwd, type);
  }

  // ------------------ API ACTION ------------------

  Future<void> _performEntityAction(
      String name, String action, String? password, String type) async {
    try {
        final url = _getInsertUrl(type);
        final deleteUrl = url.replaceAll('insert', 'delete');
        
        debugPrint('🔥 LMD ACTION: $action $type | URL: $deleteUrl | NAME: "$name"');

        http.Response response;
        
        switch (action) {
          case 'add':
            response = await http.post(
              Uri.parse(url),
              body: jsonEncode({'name': name}),
              headers: {'Content-Type': 'application/json'},
            );
            debugPrint('🔥 LMD ADD $type | STATUS: ${response.statusCode} | BODY: ${response.body}');
            if (response.statusCode != 200) {
              throw Exception('Add failed: ${response.statusCode} - ${response.body}');
            }
            break;

          case 'delete':
            response = await http.post(
              Uri.parse(deleteUrl),
              body: jsonEncode({
                'name': name,
                'password': password ?? '',
              }),
              headers: {'Content-Type': 'application/json'},
            );
            debugPrint('🔥 LMD DELETE $type | STATUS: ${response.statusCode} | BODY: ${response.body}');
            
            if (response.statusCode != 200) {
              throw Exception('Delete failed ${response.statusCode}: ${response.body}');
            }
            
            final respJson = jsonDecode(response.body);
            if (respJson['success'] != true) {
              throw Exception('Backend error: ${respJson['error'] ?? 'Unknown'}');
            }
            
            // Optimistic UI remove
            setState(() {
              if (type == 'client' && _clientList.contains(name)) _clientList.remove(name);
              if (type == 'driver' && _driverList.contains(name)) _driverList.remove(name);
              if (type == 'vehicle' && _vehicleList.contains(name)) _vehicleList.remove(name);
            });
            break;

          case 'edit':
            final delResp = await http.post(
              Uri.parse(deleteUrl),
              body: jsonEncode({
                'name': name,
                'password': password ?? '1008',
              }),
              headers: {'Content-Type': 'application/json'},
            );
            debugPrint('🔥 LMD EDIT-DEL $type | STATUS: ${delResp.statusCode} | BODY: ${delResp.body}');
            if (delResp.statusCode != 200) {
              throw Exception('Edit-delete failed: ${delResp.statusCode}');
            }

            final addResp = await http.post(
              Uri.parse(url),
              body: jsonEncode({'name': name}),
              headers: {'Content-Type': 'application/json'},
            );
            debugPrint('🔥 LMD EDIT-ADD $type | STATUS: ${addResp.statusCode} | BODY: ${addResp.body}');
            if (addResp.statusCode != 200) {
              throw Exception('Edit-add failed: ${addResp.statusCode}');
            }
            break;

          default:
            throw Exception('Unknown action: $action');
        }

        await _refreshLists();

    } catch (e) {
      debugPrint('🔥 LMD ERROR $type: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$type $action error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }


  // ------------------ DATA TABLE ------------------

  Widget _buildDataTable(ThemeData theme) {
    return Card(
      elevation: 4,
      clipBehavior: Clip.antiAlias,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _lmdDataFuture,
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Text('No entries found.', style: TextStyle(fontSize: 12)),
              ),
            );
          }

          const headerStyle =
              TextStyle(fontWeight: FontWeight.bold, fontSize: 10);
          const cellStyle = TextStyle(fontSize: 9);

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: [
                'Vehicle',
                'Driver',
                'Clients',
                'Gate No',
                'SO Linked',
                'Extra Expenses',
                'Total',
                'Payment Status',
                'Amount Paid',
                'Amount Due',
                'Mode'
              ]
                  .map((col) =>
                      DataColumn(label: Text(col, style: headerStyle)))
                  .toList(),
              rows: snapshot.data!.map((row) {
                return DataRow(cells: [
                  DataCell(Text(row['vehicle_number'] ?? '', style: cellStyle)),
                  DataCell(Text(row['driver_name'] ?? '', style: cellStyle)),
                  DataCell(Text(row['client_name'] ?? '', style: cellStyle)),
                  DataCell(Text(row['gate_number'] ?? '-', style: cellStyle)),
                  DataCell(Text(row['po_number'] ?? '-', style: cellStyle)),
                  DataCell(Text(row['extra_expenses']?.toString() ?? '0.0',style: cellStyle)),
                  DataCell(Text(row['total_amount']?.toString() ?? '0.0',style: cellStyle)),
                  DataCell(
                    Text(row['payment_status'] ?? 'Unpaid',style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        color: row['payment_status'] == 'Paid'
                            ? Colors.green
                            : (row['payment_status'] == 'Partial Paid'
                                ? Colors.orange
                                : Colors.red),
                      ),
                    ),
                  ),
                  DataCell(Text(
                      row['amount_paid']?.toString() ?? '0.0',
                      style: const TextStyle(fontSize: 9, color: Colors.green))),
                  DataCell(Text(
                      row['amount_due']?.toString() ?? '0.0',
                      style: const TextStyle(fontSize: 9, color: Colors.red))),
                  DataCell(Text(
                      row['mode_of_payment'] ?? '-',
                      style: cellStyle)),
                ]);
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}